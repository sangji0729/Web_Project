$(document).ready(function(){
    $("#headerSpace").load("header.jsp")
    $("#footerSpace").load("footer.html")
});
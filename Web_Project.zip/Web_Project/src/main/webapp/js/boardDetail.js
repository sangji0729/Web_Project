$(document).ready(function(){
    $("#headerSpace").load("header2.jsp")
    $("#footerSpace").load("footer.html")
});
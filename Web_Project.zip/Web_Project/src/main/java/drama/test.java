package drama;

public class test {

	
	public static void main(String[] args) {
		
		boolean check = true;
		int[] arr= new int[] {1,2};
		if (arr != null && check){
			System.out.println("문법 확인");
		}
}
}
